package com.student.searchroom.model;

public class HouseFilter {
    private Long maxPrice;
    private Long minPrice;
}
