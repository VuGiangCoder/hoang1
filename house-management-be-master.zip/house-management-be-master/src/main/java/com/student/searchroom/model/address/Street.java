package com.student.searchroom.model.address;

import lombok.Data;

@Data
public class Street {
    private String name;
}
