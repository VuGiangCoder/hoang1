package com.student.searchroom.model;

import lombok.Data;

@Data
public class MailDetails {
    private String subject;
    private String to;
    private String re;
}
