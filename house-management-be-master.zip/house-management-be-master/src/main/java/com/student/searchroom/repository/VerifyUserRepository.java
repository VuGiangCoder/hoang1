package com.student.searchroom.repository;

import com.student.searchroom.entity.VerifyUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VerifyUserRepository extends JpaRepository<VerifyUser, String> {
}
